 // JavaScript to toggle the currency list on click
 document.querySelector('.main__menu__select').addEventListener('click', function () {
    document.querySelector('.submenu').classList.toggle('show');
  });
  
  // JavaScript to hide the currency list on clicking the close icon
  document.querySelector('.main__menu__select').addEventListener('click', function () {
    document.querySelector('.list__currency').classList.remove('show');
  });