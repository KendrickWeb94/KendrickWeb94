document.addEventListener("DOMContentLoaded", function () {
    // Get the preloader element
    const preloader = document.querySelector(".preloader");
  
    // Function to hide the preloader
    function hidePreloader() {
      preloader.style.display = "none";
    }
  
    // Hide the preloader after 5000 milliseconds (5 seconds)
    setTimeout(hidePreloader, 2000);
  });
  
 

  
  
  
document.addEventListener("DOMContentLoaded", function () {
  // Get the pop-up element and the close button
  const popup = document.querySelector(".popup__box__context");
  const closeBtn = document.getElementById("closePopup");

  // Function to open the pop-up with a delay
  function openPopup() {
    popup.style.display = "block";
  }

  // Function to close the pop-up
  function closePopup() {
    popup.style.display = "none";
  }

  // Show the pop-up after 3000 milliseconds (3 seconds)
  setTimeout(openPopup, 3000);

  // Add event listener to close button
  closeBtn.addEventListener("click", closePopup);
});


  
  
  